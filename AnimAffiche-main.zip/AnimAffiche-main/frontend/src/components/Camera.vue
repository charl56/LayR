<template>
    <div class="detector-wrapper">
        <div class="header">
            <h1>Détecteur de Rectangles Bleus</h1>
            <p>Placez un objet rectangulaire bleu devant la caméra</p>
        </div>

        <!-- Loader OpenCV -->
        <div v-if="isLoadingOpenCV" class="loader-container">
            <div class="loader"></div>
            <p>Chargement d'OpenCV.js...</p>
            <small>Cela peut prendre quelques secondes</small>
        </div>

        <!-- Zone caméra -->
        <div v-else class="camera-zone">
            <div class="video-container">
                <video ref="video" autoplay playsinline muted></video>
                <canvas ref="overlay"></canvas>
            </div>

            <div class="controls">
                <button @click="toggleDetection" :class="['btn', isDetecting ? 'btn-stop' : 'btn-start']"
                    :disabled="!opencvReady">
                    {{ isDetecting ? 'Arrêter' : 'Démarrer la détection' }}
                </button>
            </div>

            <div v-if="detectedRect" class="info-box">
                <h3>Rectangle bleu détecté !</h3>
                <p>Position: ({{ detectedRect.x }}, {{ detectedRect.y }})</p>
                <p>Dimensions: {{ detectedRect.width }} x {{ detectedRect.height }} px</p>
                <p>Surface: {{ detectedRect.area }} px²</p>
            </div>

            <div v-if="errorMsg" class="error-box">
                {{ errorMsg }}
            </div>
        </div>
    </div>
</template>

<script setup lang="ts">
import { ref, onMounted, onBeforeUnmount } from 'vue';

interface Rectangle {
    x: number;
    y: number;
    width: number;
    height: number;
    area: number;
}

const video = ref<HTMLVideoElement | null>(null);
const overlay = ref<HTMLCanvasElement | null>(null);
const isLoadingOpenCV = ref(true);
const opencvReady = ref(false);
const isDetecting = ref(false);
const detectedRect = ref<Rectangle | null>(null);
const errorMsg = ref('');

let cv: any = null;
let stream: MediaStream | null = null;
let animationId: number | null = null;

// Vidéo à afficher dans le rectangle
const overlayVideoUrl = 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4';
let overlayVideoElement: HTMLVideoElement | null = null;

onMounted(async () => {
    await initOpenCV();
    initOverlayVideo();
});

onBeforeUnmount(() => {
    cleanup();
});

const initOverlayVideo = () => {
    console.log('[VIDEO] 🎬 Initialisation de la vidéo overlay...');
    overlayVideoElement = document.createElement('video');
    overlayVideoElement.src = overlayVideoUrl;
    overlayVideoElement.loop = true;
    overlayVideoElement.muted = true;
    overlayVideoElement.playsInline = true;

    // Pré-charger et démarrer la vidéo
    overlayVideoElement.load();
    overlayVideoElement.play().catch(err => {
        console.warn('[VIDEO] ⚠️ Autoplay bloqué, la vidéo démarrera au premier clic:', err);
    });

    console.log('[VIDEO] ✅ Vidéo overlay prête');
};

const initOpenCV = async () => {
    try {
        console.log('[OPENCV] 🔄 Début du chargement d\'OpenCV...');
        isLoadingOpenCV.value = true;

        // Vérifier si OpenCV est déjà chargé
        if ((window as any).cv) {
            console.log('[OPENCV] ✅ OpenCV déjà chargé');
            cv = (window as any).cv;
            opencvReady.value = true;
            isLoadingOpenCV.value = false;
            return;
        }

        // Charger OpenCV depuis le CDN
        console.log('[OPENCV] 📦 Chargement depuis le CDN...');
        await loadOpenCVScript();

        // Attendre que le WASM soit prêt
        console.log('[OPENCV] ⏳ Attente de l\'initialisation WASM...');
        await waitForOpenCV();

        cv = (window as any).cv;
        opencvReady.value = true;
        isLoadingOpenCV.value = false;

        console.log('[OPENCV] ✅ OpenCV chargé et prêt !');
    } catch (err) {
        console.error('[OPENCV] ❌ Erreur lors du chargement:', err);
        errorMsg.value = 'Erreur lors du chargement d\'OpenCV: ' + (err as Error).message;
        isLoadingOpenCV.value = false;
    }
};

const loadOpenCVScript = (): Promise<void> => {
    return new Promise((resolve, reject) => {
        const script = document.createElement('script');
        // Utiliser le fichier local au lieu du CDN
        script.src = '/libs/opencv.js';
        script.async = true;

        script.onload = () => {
            console.log('[OPENCV] 📜 Script chargé (local)');
            resolve();
        };

        script.onerror = () => {
            console.error('[OPENCV] ❌ Échec du chargement du script local');
            reject(new Error('Échec du chargement du script OpenCV'));
        };

        document.head.appendChild(script);
    });
};

const waitForOpenCV = (): Promise<void> => {
    return new Promise((resolve, reject) => {
        let attempts = 0;
        const maxAttempts = 300; // 30 secondes max

        console.log('[OPENCV] 🔍 Vérification de l\'initialisation...');

        const check = setInterval(() => {
            attempts++;

            if ((window as any).cv && (window as any).cv.Mat) {
                clearInterval(check);
                console.log(`[OPENCV] ✅ Initialisé après ${attempts * 100}ms`);
                resolve();
            } else if (attempts >= maxAttempts) {
                clearInterval(check);
                console.error('[OPENCV] ⏱️ Timeout atteint');
                reject(new Error('Timeout lors du chargement d\'OpenCV'));
            }

            if (attempts % 10 === 0) {
                console.log(`[OPENCV] ⏳ Attente... (${attempts * 100}ms)`);
            }
        }, 100);
    });
};

const toggleDetection = async () => {
    if (isDetecting.value) {
        stopDetection();
    } else {
        await startDetection();
    }
};

const startDetection = async () => {
    try {
        console.log('[CAMERA] 🎥 Démarrage de la détection...');
        errorMsg.value = '';

        // Demander l'accès à la caméra
        console.log('[CAMERA] 📹 Demande d\'accès à la caméra...');
        stream = await navigator.mediaDevices.getUserMedia({
            video: {
                facingMode: 'environment',
                width: { ideal: 1280 },
                height: { ideal: 720 }
            }
        });
        console.log('[CAMERA] ✅ Accès caméra accordé');

        if (video.value) {
            video.value.srcObject = stream;

            await new Promise<void>((resolve) => {
                if (video.value) {
                    video.value.onloadedmetadata = () => {
                        console.log('[CAMERA] 📐 Résolution:', video.value!.videoWidth, 'x', video.value!.videoHeight);
                        video.value!.play();
                        resolve();
                    };
                }
            });

            // Configurer le canvas
            if (overlay.value && video.value) {
                overlay.value.width = video.value.videoWidth;
                overlay.value.height = video.value.videoHeight;
                console.log('[CAMERA] 🖼️ Canvas configuré');
            }

            isDetecting.value = true;
            console.log('[DETECTION] 🔍 Début de la boucle de détection');
            detectBlueRectangles();
        }
    } catch (err) {
        console.error('[CAMERA] ❌ Erreur d\'accès à la caméra:', err);
        errorMsg.value = 'Erreur d\'accès à la caméra: ' + (err as Error).message;
    }
};

const stopDetection = () => {
    console.log('[DETECTION] 🛑 Arrêt de la détection');
    isDetecting.value = false;
    detectedRect.value = null;

    if (animationId) {
        cancelAnimationFrame(animationId);
        animationId = null;
        console.log('[DETECTION] ⏸️ Animation frame annulée');
    }

    if (stream) {
        stream.getTracks().forEach(track => track.stop());
        stream = null;
        console.log('[CAMERA] 📷 Stream caméra arrêté');
    }

    if (overlay.value) {
        const ctx = overlay.value.getContext('2d');
        if (ctx) {
            ctx.clearRect(0, 0, overlay.value.width, overlay.value.height);
            console.log('[DETECTION] 🧹 Canvas nettoyé');
        }
    }
};

const detectBlueRectangles = () => {
    if (!isDetecting.value || !video.value || !overlay.value || !cv) {
        return;
    }

    const ctx = overlay.value.getContext('2d');
    if (!ctx) return;

    try {
        // Capturer l'image de la vidéo
        const tempCanvas = document.createElement('canvas');
        tempCanvas.width = video.value.videoWidth;
        tempCanvas.height = video.value.videoHeight;
        const tempCtx = tempCanvas.getContext('2d');

        if (!tempCtx) return;

        tempCtx.drawImage(video.value, 0, 0);

        // Créer les matrices OpenCV
        const src = cv.imread(tempCanvas);
        const hsv = new cv.Mat();
        const mask = new cv.Mat();
        const contours = new cv.MatVector();
        const hierarchy = new cv.Mat();

        // Convertir BGR vers HSV
        cv.cvtColor(src, hsv, cv.COLOR_RGB2HSV);

        // Définir la plage de bleu en HSV
        // Bleu: H = 100-130, S = 50-255, V = 50-255
        const lowerBlue = new cv.Mat(hsv.rows, hsv.cols, hsv.type(), [100, 50, 50, 0]);
        const upperBlue = new cv.Mat(hsv.rows, hsv.cols, hsv.type(), [130, 255, 255, 255]);

        // Créer le masque pour la couleur bleue
        cv.inRange(hsv, lowerBlue, upperBlue, mask);

        // Opérations morphologiques pour nettoyer le masque
        const kernel = cv.Mat.ones(5, 5, cv.CV_8U);
        cv.morphologyEx(mask, mask, cv.MORPH_CLOSE, kernel);
        cv.morphologyEx(mask, mask, cv.MORPH_OPEN, kernel);

        // Trouver les contours
        cv.findContours(mask, contours, hierarchy, cv.RETR_EXTERNAL, cv.CHAIN_APPROX_SIMPLE);

        const nbContours = contours.size();
        if (nbContours > 0) {
            console.log(`[DETECTION] 🔎 ${nbContours} contour(s) trouvé(s)`);
        }

        // Effacer l'overlay
        ctx.clearRect(0, 0, overlay.value.width, overlay.value.height);

        // Trouver le plus grand rectangle bleu
        let maxArea = 0;
        let bestRect: Rectangle | null = null;

        for (let i = 0; i < contours.size(); i++) {
            const contour = contours.get(i);
            const area = cv.contourArea(contour);

            // Filtrer les contours trop petits
            if (area < 3000) {
                contour.delete();
                continue;
            }

            console.log(`[DETECTION] 📏 Contour ${i}: surface = ${Math.round(area)} px²`);

            // Approximation du contour
            const peri = cv.arcLength(contour, true);
            const approx = new cv.Mat();
            cv.approxPolyDP(contour, approx, 0.02 * peri, true);

            console.log(`[DETECTION] 🔷 Contour ${i}: ${approx.rows} côtés`);

            // Vérifier si c'est un quadrilatère
            if (approx.rows === 4 && area > maxArea) {
                const rect = cv.boundingRect(approx);

                // Vérifier l'aspect ratio
                const aspectRatio = rect.width / rect.height;
                console.log(`[DETECTION] 📐 Contour ${i}: ratio = ${aspectRatio.toFixed(2)}`);

                if (aspectRatio > 0.2 && aspectRatio < 5) {
                    maxArea = area;
                    bestRect = {
                        x: rect.x,
                        y: rect.y,
                        width: rect.width,
                        height: rect.height,
                        area: Math.round(area)
                    };
                    console.log(`[DETECTION] ✅ Meilleur rectangle trouvé !`, bestRect);
                }
            }

            approx.delete();
            contour.delete();
        }

        // Dessiner le rectangle détecté
        if (bestRect) {
            console.log(`[DETECTION] 🎯 Rectangle bleu détecté à (${bestRect.x}, ${bestRect.y})`);

            // Dessiner la vidéo dans le rectangle
            if (overlayVideoElement && overlayVideoElement.readyState >= 2) {
                ctx.save();

                // Créer un chemin de découpe pour le rectangle
                ctx.beginPath();
                ctx.rect(bestRect.x, bestRect.y, bestRect.width, bestRect.height);
                ctx.clip();

                // Dessiner la vidéo dans le rectangle (avec ajustement pour remplir)
                ctx.drawImage(
                    overlayVideoElement,
                    bestRect.x,
                    bestRect.y,
                    bestRect.width,
                    bestRect.height
                );

                ctx.restore();

                console.log('[VIDEO] 🎥 Vidéo affichée dans le rectangle');
            }

            // Rectangle principal en vert (bordure)
            ctx.strokeStyle = '#00ff00';
            ctx.lineWidth = 4;
            ctx.strokeRect(bestRect.x, bestRect.y, bestRect.width, bestRect.height);

            // Coins
            ctx.fillStyle = '#00ff00';
            const corners = [
                { x: bestRect.x, y: bestRect.y },
                { x: bestRect.x + bestRect.width, y: bestRect.y },
                { x: bestRect.x, y: bestRect.y + bestRect.height },
                { x: bestRect.x + bestRect.width, y: bestRect.y + bestRect.height }
            ];

            corners.forEach(corner => {
                ctx.beginPath();
                ctx.arc(corner.x, corner.y, 10, 0, 2 * Math.PI);
                ctx.fill();
            });

            // Label
            ctx.fillStyle = '#00ff00';
            ctx.font = 'bold 20px Arial';
            ctx.shadowColor = 'black';
            ctx.shadowBlur = 5;
            ctx.fillText('Rectangle bleu + Vidéo', bestRect.x, bestRect.y - 10);
            ctx.shadowBlur = 0;

            detectedRect.value = bestRect;
        } else {
            detectedRect.value = null;
        }

        // Nettoyer
        src.delete();
        hsv.delete();
        mask.delete();
        lowerBlue.delete();
        upperBlue.delete();
        contours.delete();
        hierarchy.delete();
        kernel.delete();

    } catch (err) {
        console.error('[DETECTION] ❌ Erreur de traitement:', err);
    }

    // Continuer la boucle
    animationId = requestAnimationFrame(detectBlueRectangles);
};

const cleanup = () => {
    stopDetection();

    if (overlayVideoElement) {
        overlayVideoElement.pause();
        overlayVideoElement.src = '';
        overlayVideoElement = null;
        console.log('[VIDEO] 🗑️ Vidéo overlay nettoyée');
    }
};
</script>

<style scoped>
* {
    cursor: auto !important;
}

.detector-wrapper {
    min-height: 100vh;
    background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
    padding: 20px;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

.header {
    text-align: center;
    color: white;
    margin-bottom: 30px;
}

.header h1 {
    font-size: 2.5rem;
    margin-bottom: 10px;
    text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
}

.header p {
    font-size: 1.2rem;
    opacity: 0.9;
}

.loader-container {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    min-height: 400px;
    background: white;
    border-radius: 12px;
    max-width: 600px;
    margin: 0 auto;
    padding: 40px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
}

.loader {
    width: 60px;
    height: 60px;
    border: 6px solid #f3f3f3;
    border-top: 6px solid #2a5298;
    border-radius: 50%;
    animation: spin 1s linear infinite;
    margin-bottom: 20px;
}

@keyframes spin {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(360deg);
    }
}

.loader-container p {
    font-size: 1.3rem;
    color: #333;
    margin: 10px 0;
    font-weight: 600;
}

.loader-container small {
    color: #666;
    font-size: 0.9rem;
}

.camera-zone {
    max-width: 1000px;
    margin: 0 auto;
}

.video-container {
    position: relative;
    background: black;
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 10px 40px rgba(0, 0, 0, 0.5);
    margin-bottom: 20px;
}

video {
    width: 100%;
    height: auto;
    display: block;
}

canvas {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
}

.controls {
    text-align: center;
    margin-bottom: 20px;
}

.btn {
    padding: 15px 40px;
    font-size: 1.1rem;
    font-weight: 600;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.3s ease;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
}

.btn:disabled {
    opacity: 0.5;
    cursor: not-allowed;
}

.btn-start {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
}

.btn-start:hover:not(:disabled) {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4);
}

.btn-stop {
    background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
    color: white;
}

.btn-stop:hover:not(:disabled) {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(245, 87, 108, 0.4);
}

.info-box {
    background: linear-gradient(135deg, #84fab0 0%, #8fd3f4 100%);
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
    color: #1a3a52;
}

.info-box h3 {
    margin-top: 0;
    margin-bottom: 15px;
    font-size: 1.4rem;
}

.info-box p {
    margin: 8px 0;
    font-size: 1rem;
    font-family: 'Courier New', monospace;
}

.error-box {
    background: #ff6b6b;
    color: white;
    padding: 15px;
    border-radius: 8px;
    margin-top: 20px;
    box-shadow: 0 4px 15px rgba(255, 107, 107, 0.3);
}
</style>