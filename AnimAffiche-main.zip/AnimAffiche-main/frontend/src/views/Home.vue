<script setup lang="ts">
// Import du composant depuis le dossier components
import Camera from '@/components/Camera.vue'
</script>

<template>
    <div class="home">
        <Camera />
    </div>
</template>

<style scoped>
.home {
	height: 100%;
    width: 100%;
}
</style>